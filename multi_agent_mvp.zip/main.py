from agents.researcher import ResearchAgent
from agents.planner import PlannerAgent
from agents.executor import ExecutorAgent
from core.memory import Memory
from core.message_bus import MessageBus
from orchestrator import Orchestrator

def main():
    researcher = ResearchAgent("R1", "研究员")
    planner = PlannerAgent("P1", "策略分析师")
    executor = ExecutorAgent("E1", "执行官")

    memory = Memory()
    bus = MessageBus()

    system = Orchestrator(researcher, planner, executor, memory, bus)

    task = "分析2025年AI产业投资机会"
    result = system.run(task)

    print("\n=== FINAL RESULT ===\n")
    print(result)

if __name__ == "__main__":
    main()
