from agents.base import BaseAgent

class ExecutorAgent(BaseAgent):
    def run(self, plan):
        prompt = f"""
执行以下计划：
{plan}

请输出最终结果（可包含分析结论）
"""
        return super().run(prompt)
