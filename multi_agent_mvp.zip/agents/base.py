from core.llm import call_llm

class BaseAgent:
    def __init__(self, name, role):
        self.name = name
        self.role = role

    def run(self, input_text):
        prompt = f"""
你是{self.role}

任务输入:
{input_text}

请输出你的结果：
"""
        return call_llm(prompt)
