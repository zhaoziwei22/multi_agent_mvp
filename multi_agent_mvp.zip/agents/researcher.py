from agents.base import BaseAgent

class ResearchAgent(BaseAgent):
    def run(self, task):
        prompt = f"""
任务：{task}

请完成：
1. 收集相关背景信息
2. 提供关键数据点
3. 输出结构化摘要
"""
        return super().run(prompt)
