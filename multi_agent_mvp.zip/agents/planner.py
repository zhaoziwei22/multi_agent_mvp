from agents.base import BaseAgent

class PlannerAgent(BaseAgent):
    def run(self, research):
        prompt = f"""
基于以下研究内容：
{research}

请：
1. 拆解任务
2. 形成执行步骤（step1, step2...）
"""
        return super().run(prompt)
