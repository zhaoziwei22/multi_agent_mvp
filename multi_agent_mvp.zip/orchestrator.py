class Orchestrator:
    def __init__(self, researcher, planner, executor, memory, bus):
        self.researcher = researcher
        self.planner = planner
        self.executor = executor
        self.memory = memory
        self.bus = bus

    def run(self, task):
        research = self.researcher.run(task)
        self.memory.write("research", research)

        plan = self.planner.run(research)
        self.memory.write("plan", plan)

        result = self.executor.run(plan)
        self.memory.write("result", result)

        return result
